import fs from 'fs';
import path from 'path';
import { io } from 'socket.io-client'; // WebSocket клиент
import fetch from 'node-fetch';
import { exec, execSync } from 'child_process';

// Абсолютный путь до конфигурационного файла
const configPath = path.resolve(__dirname, '../config/agent.config.json');

// Загрузка и парсинг конфигурации агента
let config: any;
try {
  const raw = fs.readFileSync(configPath, 'utf-8');
  config = JSON.parse(raw);
  console.log('[Agent] Конфигурация успешно загружена:');
  console.log('Имя ПК:', config.pcName);
  console.log('Путь к играм:', config.gamesDirectory);
} catch (err) {
  console.error('[Agent] Ошибка загрузки конфигурации:', err);
  process.exit(1);
}

// Обновляем функцию для получения списка игр из папок
function getAvailableGames(directories: string[]): string[] {
  const games: string[] = [];

  directories.forEach((directory) => {
    try {
      const folders = fs.readdirSync(directory, { withFileTypes: true })
        .filter(dirent => dirent.isDirectory() && dirent.name !== 'SteamVR' && dirent.name !== 'Steamworks Shared')
        .map(dirent => dirent.name);

      console.log(`[Agent] Найдено ${folders.length} игр в директории ${directory}`);
      games.push(...folders);
    } catch (err) {
      console.error(`[Agent] Ошибка чтения директории ${directory}:`, err);
    }
  });

  return games;
}

const CURRENT_VERSION = '1.0.0';

// Указываем тип для ответа сервера
interface UpdateResponse {
  version: string;
  updateUrl: string;
}

async function checkForUpdates() {
  try {
    const response = await fetch(`${config.serverUrl}/api/agent/version`);
    const { version, updateUrl } = (await response.json()) as UpdateResponse;

    if (version !== CURRENT_VERSION) {
      console.log(`[Agent] Доступно обновление: ${version}`);
      await downloadAndUpdate(updateUrl);
    } else {
      console.log('[Agent] Клиент актуален.');
    }
  } catch (error) {
    console.error('[Agent] Ошибка проверки обновлений:', error);
  }
}

async function downloadAndUpdate(url: string) {
  const response = await fetch(url);

  if (!response.body) {
    console.error('[Agent] Ошибка: тело ответа отсутствует.');
    return;
  }

  const fileStream = fs.createWriteStream('./update.zip');
  response.body.pipe(fileStream);

  fileStream.on('finish', () => {
    console.log('[Agent] Обновление загружено. Распаковка...');
    exec('unzip -o update.zip -d ./', (err) => {
      if (err) {
        console.error('[Agent] Ошибка распаковки обновления:', err);
        return;
      }
      console.log('[Agent] Обновление завершено. Перезапуск...');
      process.exit(0); // Завершаем процесс для перезапуска
    });
  });
}

function backupAndMergeConfig(newConfigPath: string, currentConfigPath: string) {
  const backupPath = currentConfigPath.replace('agent.config.json', 'agent.config.backup.json');

  // Создаём резервную копию текущего файла
  fs.copyFileSync(currentConfigPath, backupPath);
  console.log(`[Agent] Резервная копия конфигурации создана: ${backupPath}`);

  // Читаем текущую и новую конфигурации
  const currentConfig = JSON.parse(fs.readFileSync(currentConfigPath, 'utf-8'));
  const newConfig = JSON.parse(fs.readFileSync(newConfigPath, 'utf-8'));

  // Объединяем конфигурации
  const mergedConfig = { ...newConfig, ...currentConfig };

  // Добавляем комментарии для новых полей
  for (const key in newConfig) {
    if (!(key in currentConfig)) {
      console.log(`[Agent] Новое поле в конфигурации: ${key} (добавлено с заглушкой)`);
      mergedConfig[key] = `Значение для ${key} (заглушка)`; // Заглушка с пояснением
    }
  }

  // Сохраняем объединённую конфигурацию
  fs.writeFileSync(currentConfigPath, JSON.stringify(mergedConfig, null, 2), 'utf-8');
  console.log(`[Agent] Конфигурация обновлена: ${currentConfigPath}`);
}

async function updateAgent() {
  const updateUrl = `${config.serverUrl}/updates/agent.zip`;
  const updatePath = './agent_update.zip';

  console.log('[Agent] Загрузка обновления...');
  const response = await fetch(updateUrl);

  if (!response.body) {
    console.error('[Agent] Ошибка: тело ответа отсутствует.');
    return;
  }

  const fileStream = fs.createWriteStream(updatePath);
  response.body.pipe(fileStream);

  fileStream.on('finish', () => {
    console.log('[Agent] Распаковка обновления...');
    execSync(`unzip -o ${updatePath} -d ./`);

    // Обновляем конфигурацию
    backupAndMergeConfig('./agent.config.json', configPath);

    console.log('[Agent] Обновление завершено. Перезапуск...');
    process.exit(0);
  });
}

// Вызов проверки обновлений при старте
checkForUpdates();

// === Подключение к серверу WebSocket ===
const socket = io(config.serverUrl, {
  transports: ['websocket'],
  reconnectionAttempts: 5
});

socket.on('connect', () => {
  console.log('[Agent] Подключён к серверу:', socket.id);

  // Отправка первичного статуса
  socket.emit('status', {
    pcName: config.pcName,
    status: 'idle',
    timestamp: new Date().toISOString()
  });

  setInterval(() => {
    socket.emit('status', {
      pcName: config.pcName,
      status: 'idle', // позже может быть "running"
      timestamp: new Date().toISOString()
    });
  }, config.heartbeatIntervalMs || 5000);
});

socket.on('disconnect', () => {
  console.log('[Agent] Отключён от сервера');
});

// Обработчик для получения списка игр
socket.on('get_games', () => {
  const games = getAvailableGames(config.gamesDirectories);
  socket.emit('games_list', games);
});

// Вызов обновления агента
updateAgent();
